package sudokugame;

public class GameState {

    private Sudoku sudoku;

    public GameState() {
        sudoku = null;
    }

    public void setGameState(Sudoku sudoku) {
        this.sudoku = sudoku;
    }

    public Sudoku getGameState() {
        return sudoku;
    }

}
