package sudokugame;

import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public abstract class Sudoku {

    public JFrame frame = new JFrame();
    JFrame askUser;
    int prevBoard[][] = new int[9][9];
    int level;
    boolean isStarted = false;
    public JLabel difficultyLabel = new JLabel("Select levels:");
    public JRadioButton hardButton = new JRadioButton("Hard level");
    public JRadioButton easyButton = new JRadioButton("Easy level");
    JButton startButton = new JButton("Start");
    final JTextField grid[][] = new JTextField[9][9];
    public static JLabel name, point = new JLabel("Total Point is: 0");

    public Sudoku() {
        frame.setBounds(100, 100, 668, 438);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        //////////////////////////////////GRID START /////////////////////////////////////////////////////////////
        int h = 12, w = 13, hi = 39, wi = 37;

        for (int i = 0; i < 9; i++) {
            if (i % 3 == 0 && i != 0) {
                w += 13;
            }

            for (int j = 0; j < 9; j++) {
                if (j % 3 == 0 && j != 0) {
                    h += 11;
                }

                grid[i][j] = new JTextField();
                grid[i][j].setColumns(10);
                grid[i][j].setBounds(h, w, 38, 37);
                frame.getContentPane().add(grid[i][j]);

                h += hi;
            }
            h = 12;
            w += wi;
        }

        askUser = new JFrame();
        askUser.setSize(350, 250);
        askUser.setVisible(false);

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                grid[i][j].setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.BOLD, 22));
                grid[i][j].setHorizontalAlignment(SwingConstants.CENTER);
                grid[i][j].setEditable(false);
            }
        }
        //////////////////////////////////  GRID END  /////////////////////////////////////////////////////////////
        difficultyLabel.setFont(new Font("Calibri Light", Font.BOLD, 16));
        difficultyLabel.setBounds(435, 120, 155, 24);
        frame.getContentPane().add(difficultyLabel);

        easyButton.setFont(new Font("Calibri Light", Font.BOLD, 13));
        easyButton.setBounds(435, 143, 127, 25);
        frame.getContentPane().add(easyButton);

        hardButton.setFont(new Font("Calibri Light", Font.BOLD, 13));
        hardButton.setBounds(435, 173, 133, 25);
        frame.getContentPane().add(hardButton);

        ButtonGroup bg = new ButtonGroup();
        bg.add(easyButton);
        bg.add(hardButton);

        JTextArea alert = new JTextArea("When entering the number,"
                + "\n please press on enter button!");
        alert.setFont(new Font("Calibri Light", Font.BOLD, 18));
        alert.setBounds(405, 265, 235, 50);
        frame.getContentPane().add(alert);

        name = new JLabel("Name: " + MainPage.player.getName());
        name.setFont(new Font("Calibri Light", Font.BOLD, 18));
        name.setBounds(435, 55, 135, 23);
        frame.getContentPane().add(name);

    }

    public void createBoard(JRadioButton easyButton, JRadioButton hardButton) {
        if (isStarted) {
            isStarted = false;
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    grid[i][j].setEditable(false);
                    grid[i][j].setText(Integer.toString(prevBoard[i][j]));
                }
            }
            startButton.setText("Start");
        } else {
            // Default is easy.
            if (easyButton.isSelected()) {
                level = 0;
            } else if (hardButton.isSelected()) {
                level = 1;
            }
            int board[][] = new int[9][9];
            do {
                board = SudokuGenerator.generate(level);
                ///////////////////////////////////////////
            } while (board[0][0] == -1);
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    prevBoard[i][j] = board[i][j];
                }
            }
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    if (board[i][j] != 0) {
                        grid[i][j].setText(Integer.toString(board[i][j]));
                    } else {
                        grid[i][j].setText("");
                        grid[i][j].setEditable(true);
                        CheckNumber checkNumber = new CheckNumber(grid, prevBoard, level);
                        grid[i][j].addActionListener(checkNumber);
                    }
                }
            }
            startButton.setVisible(false);
            if (level == 0) {
                hardButton.setVisible(false);
            } else if (level == 1) {
                easyButton.setVisible(false);
            }
            isStarted = true;
        }

    }

    public abstract void New(GameState state);
}
