package sudokugame;

public class Player {

    private static Player player = null;
    private String name;
    private int easypoints;
    private int hardpoints;

    private Player() {
        easypoints = 0;
        hardpoints = 0;
    }

    public static Player getPlayer() {
        if (player == null) {
            player = new Player();
        }
        return player;
    }

    public String getName() {
        return name;
    }

    public int getEasypoints() {
        return easypoints;
    }

    public int getHardpoints() {
        return hardpoints;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEasypoints(int easypoints) {
        this.easypoints = easypoints;
    }

    public void setHardpoints(int hardpoints) {
        this.hardpoints = hardpoints;
    }

    public int setEasypointsR(int points) {
        this.easypoints = points;
        return points;
    }

    public int setHardpointsR(int points) {
        this.hardpoints = points;
        return points;
    }
}
