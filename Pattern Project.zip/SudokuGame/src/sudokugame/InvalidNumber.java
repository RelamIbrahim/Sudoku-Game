package sudokugame;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class InvalidNumber extends GameStrategy {

    public InvalidNumber(JTextField[][] grid1, int[][] easyBoard1, int[][] hardBoard1, int level1, int rowSelected1, int colSelected1) {
        super(grid1, easyBoard1, hardBoard1, level1, rowSelected1, colSelected1);

    }

    @Override
    public int Message(int number) {
        DisplayMessage();
        again.setFont(new Font("Calibri Light", Font.BOLD, 18));
        again.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grid[rowSelected][colSelected].setText(null);
                message.setVisible(false);
            }
        });

        label = new JLabel("The inserted number " + number + " is not correct.");
        message.setLayout(new GridLayout(4, 1));
        message.getContentPane().add(label);
        message.getContentPane().add(again);
        message.getContentPane().add(mainMenu);
        message.getContentPane().add(stop);
        message.setVisible(true);
        if (level == 0) {
            if (MainPage.player.getEasypoints() > 2) {
                points = MainPage.player.getEasypoints();
                newPoints = MainPage.player.setEasypointsR(points - reduce);
            } else {
                newPoints = MainPage.player.setEasypointsR(0);
            }
        } else if (level == 1) {
            if (MainPage.player.getHardpoints() > 2) {
                points = MainPage.player.getHardpoints();
                newPoints = MainPage.player.setHardpointsR(points - reduce);
            } else {
                newPoints = MainPage.player.setHardpointsR(0);
            }
        }
        return newPoints;
 
    }

}
