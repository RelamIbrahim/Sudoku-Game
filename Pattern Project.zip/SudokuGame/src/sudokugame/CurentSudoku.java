package sudokugame;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;

public class CurentSudoku extends Sudoku {

    JLabel label;
    final JButton resuneGame = new JButton("Resume Game");
    final JButton newGame = new JButton("New Game");
    int board[][] = new int[9][9];
    boolean isStarted = false;

    @Override
    public void New(GameState state) {
        startButton.setBounds(435, 210, 155, 37);
        frame.getContentPane().add(startButton);
        startButton.setFont(new Font("Calibri Light", Font.BOLD, 18));
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                if (isStarted) {
                    isStarted = false;
                    for (int i = 0; i < 9; i++) {
                        for (int j = 0; j < 9; j++) {
                            grid[i][j].setEditable(false);
                            grid[i][j].setText(Integer.toString(prevBoard[i][j]));
                        }
                    }
                    startButton.setText("Start");
                } else {
                    // Default is easy.
                    if (easyButton.isSelected()) {
                        level = 0;
                    } else if (hardButton.isSelected()) {
                        level = 1;
                    }

                    /////////////////////////////////////////////////////////////
                    label = new JLabel("What do you whant?");
                    label.setFont(new Font("Calibri Light", Font.BOLD, 20));
                    label.setBounds(205, 80, 255, 24);
                    frame.getContentPane().add(difficultyLabel);
                    askUser.setLayout(new GridLayout(3, 1));
                    askUser.getContentPane().add(label);
                    askUser.getContentPane().add(resuneGame);
                    askUser.getContentPane().add(newGame);
                    askUser.setVisible(true);

                    resuneGame.setFont(new Font("Calibri Light", Font.BOLD, 18));
                    resuneGame.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            if (easyButton.isSelected()) {
                                level = 0;
                                getCurentBoard1(level, MainPage.getoldBoard1());
                                point.setText("Total Point is:  " + MainPage.player.getEasypoints());
                            }
                            if (hardButton.isSelected()) {
                                level = 1;
                                getCurentBoard2(level, MainPage.getoldBoard2());
                                point.setText("Total Point is:  " + MainPage.player.getHardpoints());
                            }
                            askUser.setVisible(false);
                            startButton.setVisible(false);
                            isStarted = true;
                        }
                    });

                    newGame.setFont(new Font("Calibri Light", Font.BOLD, 18));
                    newGame.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(java.awt.event.ActionEvent evt) {

                            if (level == 0) {
                                MainPage.player.setEasypoints(0);
                                point.setText("Total Point is:  " + MainPage.player.getEasypoints());
                                createBoard(easyButton, hardButton);
                                point.setVisible(true);
                            }
                            if (level == 1) {
                                MainPage.player.setHardpoints(0);
                                point.setText("Total Point is:  " + MainPage.player.getHardpoints());
                                createBoard(easyButton, hardButton);
                                point.setVisible(true);
                            }
                            askUser.setVisible(false);
                        }
                    });
                    isStarted = true;
                    if (level == 0) {
                        hardButton.setVisible(false);
                    } else if (level == 1) {
                        easyButton.setVisible(false);
                    }
                }
            }
        });

        point.setFont(new Font("Calibri Light", Font.BOLD, 18));
        point.setBounds(435, 75, 135, 23);
        frame.getContentPane().add(point);
        
        state.setGameState(this);
    }

    public void getCurentBoard1(int level, int oldBoard1[][]) {
        do {
            board = oldBoard1;
        } while (board[0][0] == -1);
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (board[i][j] != 0) {
                    grid[i][j].setText(Integer.toString(board[i][j]));
                } else {
                    grid[i][j].setText("");
                    grid[i][j].setEditable(true);
                    CheckNumber listener = new CheckNumber(grid, board, level);
                    grid[i][j].addActionListener(listener);
                }
            }
        }
    }

    public void getCurentBoard2(int level, int oldBoard2[][]) {
        do {
            board = oldBoard2;
        } while (board[0][0] == -1);
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (board[i][j] != 0) {
                    grid[i][j].setText(Integer.toString(oldBoard2[i][j]));
                } else {
                    grid[i][j].setText("");
                    grid[i][j].setEditable(true);
                    CheckNumber listener = new CheckNumber(grid, board, level);
                    grid[i][j].addActionListener(listener);
                }
            }
        }
    }

}
