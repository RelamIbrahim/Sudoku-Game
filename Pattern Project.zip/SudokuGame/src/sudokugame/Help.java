package sudokugame;

import java.awt.FlowLayout;
import javax.swing.*;

public class Help extends JFrame {

    public static void helpMessage(){
        JFrame helpfarme = new JFrame("HELP");
        helpfarme.setSize(400, 350);
        helpfarme.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        helpfarme.setLayout(new FlowLayout(FlowLayout.CENTER));
        helpfarme.setVisible(true);

        //panel How to play Sudoku
        JPanel title = new JPanel();
        title.setBorder(BorderFactory.createTitledBorder("How to play Sudoku:"));
        title.setBounds(45, 100, 400, 600);
        helpfarme.add(title);

        /*
        Step 1: The player will put his name and it consists
of 3 to 8 letters
Step 2: The player will choose the level they want to
play in
Step 3: The player will choose the square to play in
so that any row and column contains a repeating
number from 1 to S and any section consisting of 3 x
-3 boxes contains a repeating number from 1 to 9
Step 4: It will allow the player to choose multiple
options such as stop playing or go to the home page
         */
        //TextArea Steps
        JTextArea helpContent = new JTextArea("Step 1: The player will put his name and it consists\n"
                + "of 3 to 8 letters\n"
                + "\n"
                + "Step 2: The player will choose the level they want to\n"
                + "play in\n"
                + "\n"
                + "Step 3: The player will choose the square to play in\n"
                + "so that any row and column contains a repeating\n"
                + "number from 1 to S and any section consisting of 3 x\n"
                + "-3 boxes contains a repeating number from 1 to 9\n"
                + "\n"
                + "Step 4: It will allow the player to choose multiple\n"
                + "options such as stop playing or go to the home page");
        helpContent.setBounds(20, 20, 350, 350);
        title.add(helpContent);

        //Button Ok
        JButton ok = new JButton("OK");
        ok.setBounds(250, 350, 120, 25);
        helpfarme.add(ok);
        ok.addActionListener(e -> {
            helpfarme.dispose();

        });
    }
}
