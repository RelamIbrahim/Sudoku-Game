package sudokugame;

import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public abstract class GameStrategy {

    JFrame message;
    public JFrame Menu;
    final JButton again = new JButton("Try Again");
    final JButton mainMenu = new JButton("Main Menu");
    final JButton stop = new JButton("Stop");
    final JButton continueButton = new JButton("Continue");
    
    JTextField grid[][] = new JTextField[9][9];
    int easyBoard[][] = new int[9][9];
    int hardBoard[][] = new int[9][9];
    int rowSelected = -1;
    int colSelected = -1;
    int level;
    int newPoints;
    int points;
    public int number;
    JLabel label;
    int reduce = 2;
    int increase = 5;
    
    public GameStrategy(JTextField[][] grid1, int[][] easyBoard1, int[][] hardBoard1, int level1, int rowSelected1, int colSelected1) {
        this.grid = grid1;
        this.easyBoard = easyBoard1;
        this.hardBoard = hardBoard1;
        this.level = level1;
        this.rowSelected = rowSelected1;
        this.colSelected = colSelected1;
       
    }
    
    public void DisplayMessage(){
        message = new JFrame();
        message.setSize(350, 250);
        message.setVisible(false);

        mainMenu.setFont(new Font("Calibri Light", Font.BOLD, 18));
        mainMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                //Frame First
                Menu = new JFrame();
                Menu.setTitle("Sudoku Game");
                Menu.setSize(500, 350);
                Menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                //Panel Add User
                JPanel panel = new JPanel(null);
                panel.setBorder(BorderFactory.createTitledBorder("Menu"));
                panel.setBounds(45, 20, 400, 270);
                Menu.add(panel);

                //Button Play
                JButton play = new JButton("Play");
                play.setBounds(180, 120, 130, 25);
                panel.add(play);
                play.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        SudokuMaker window = new SudokuMaker();
                        window.CurrentBoard();
                        Menu.setVisible(false);
                    }
                });

                //Button Help
                JButton help = new JButton("Help");
                help.setBounds(150, 210, 95, 25);
                panel.add(help);
                help.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        MainPage.help.helpMessage();
                    }
                });

                //Button Exit
                JButton exit = new JButton("Exit");
                exit.setBounds(260, 210, 95, 25);
                panel.add(exit);
                exit.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        //Exit Button Code
                        JFrame exitfarme = new JFrame("EXIT");
                        if (JOptionPane.showConfirmDialog(exitfarme, "Confirm if you want Exit", "EXIT",
                                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
                            System.exit(0);
                        }
                    }
                });
                Menu.setVisible(true);
            }
        });

        stop.setFont(new Font("Calibri Light", Font.BOLD, 18));
        stop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SudokuMaker window = new SudokuMaker();
                window.CurrentBoard();
            }
        });
    }
    
        public abstract int Message(int number);

}
