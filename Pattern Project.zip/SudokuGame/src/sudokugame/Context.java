package sudokugame;

public class Context {

    private GameStrategy strategy;

    public Context(GameStrategy strategy) {
        this.strategy = strategy;
    }

    public int executeStrategy(int number) {
        return strategy.Message(number);
    }

}
