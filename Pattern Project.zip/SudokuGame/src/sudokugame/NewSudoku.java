package sudokugame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class NewSudoku extends Sudoku {

    @Override
    public void New(GameState state) {
        startButton.setBounds(435, 210, 155, 37);
        frame.getContentPane().add(startButton);
        startButton.setFont(new Font("Calibri Light", Font.BOLD, 18));
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                createBoard(easyButton, hardButton);
            }
        });
        if (level == 0) {
            point = new JLabel("Total Point is: 0");
        } else if (level == 1) {
            point = new JLabel("Total Point is: 0");
        }
        point.setFont(new Font("Calibri Light", Font.BOLD, 18));
        point.setBounds(435, 75, 135, 23);
        frame.getContentPane().add(point);

        state.setGameState(this);
    }
}
