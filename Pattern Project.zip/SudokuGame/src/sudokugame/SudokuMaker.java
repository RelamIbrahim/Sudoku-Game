package sudokugame;

public class SudokuMaker {

    private Sudoku curentSudoku;
    private Sudoku newSudoku;
    private GameState state;

    public SudokuMaker() {
        curentSudoku = new CurentSudoku();
        newSudoku = new NewSudoku();
        state = new GameState();
    }

    public void newBoard() {
        newSudoku.New(state);
        newSudoku.frame.setVisible(true);
    }

    public void CurrentBoard() {
        curentSudoku.New(state);
        curentSudoku.frame.setVisible(true);
    }
}
