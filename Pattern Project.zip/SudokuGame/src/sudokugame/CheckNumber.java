package sudokugame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class CheckNumber implements ActionListener {

    String enterNumber;
    public int number;

    JTextField grid[][] = new JTextField[9][9];
    int prevBoard[][] = new int[9][9];
    int easyBoard[][] = new int[9][9];
    int hardBoard[][] = new int[9][9];
    int rowSelected = -1;
    int colSelected = -1;
    int level;

    CheckNumber(JTextField grid[][], int prevBoard[][], int level) {
        this.grid = grid;
        this.prevBoard = prevBoard;
        if (level == 0) {
            this.easyBoard = prevBoard;
        } else if (level == 1) {
            this.hardBoard = prevBoard;
        }
        this.level = level;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JTextField source = (JTextField) e.getSource();
        boolean found = false;
        for (int row = 0; row < 9 && !found; ++row)// Scan fields for all rows and columns +
        //match with the source object
        {
            for (int col = 0; col < 9 && !found; ++col) {
                if (grid[row][col] == source) {
                    rowSelected = row;
                    colSelected = col;
                    found = true;  // break the inner/outer loops
                }
            }
        }
        enterNumber = grid[rowSelected][colSelected].getText(); //get input
        number = Integer.parseInt(enterNumber);

        if (number > 0 && number <= 9) {
            if (isMoveValid(rowSelected, colSelected, number, prevBoard)) {
                GameStrategy valid = new ValidNumber(grid, easyBoard, hardBoard, level, rowSelected, colSelected);
                Context contextValid = new Context(valid);
                int newPoints = contextValid.executeStrategy(number);
                Sudoku.point.setText("Total Point is: " + (newPoints));
            } else {
                GameStrategy invalid = new InvalidNumber(grid, easyBoard, hardBoard, level, rowSelected, colSelected);
                Context contextInvalid = new Context(invalid);
                int newPoints = contextInvalid.executeStrategy(number);
                Sudoku.point.setText("Total Point is: " + (newPoints));
            }
        } else {
            JOptionPane.showMessageDialog(null, new String[]{"Sorry!! ", "but the number should between 1 to 9 digits"}, "Alert", JOptionPane.WARNING_MESSAGE);
        }
    }

    public boolean isMoveValid(int x, int y, int move, int board[][]) {

        //To check the column constraint.
        for (int i = 0; i < 9; i++) {
            if (board[i][y] == move) {
                return false;
            }
        }

        //To check the row constraint.
        for (int i = 0; i < 9; i++) {
            if (board[x][i] == move) {
                return false;
            }
        }

        //To check the sub-box.
        for (int i = (x / 3) * 3; i < (x / 3) * 3 + 3; i++) {
            for (int j = (y / 3) * 3; j < (y / 3) * 3 + 3; j++) {
                if (board[i][j] == move) {
                    return false;
                }
            }
        }
        //After all checks, return true.
        return true;
    }

}
