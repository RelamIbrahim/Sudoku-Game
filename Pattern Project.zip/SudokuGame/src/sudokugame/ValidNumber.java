package sudokugame;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ValidNumber extends GameStrategy {

    public ValidNumber(JTextField[][] grid1, int[][] easyBoard1, int[][] hardBoard1, int level1, int rowSelected1, int colSelected1) {
        super(grid1, easyBoard1, hardBoard1, level1,rowSelected1,colSelected1);

    }

    @Override
    public int Message(int number) {
        DisplayMessage();
        continueButton.setFont(new Font("Calibri Light", Font.BOLD, 18));
        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                message.setVisible(false);
            }
        });

        label = new JLabel("The inserted number " + number + " is correct.");
        message.setLayout(new GridLayout(4, 1));
        message.getContentPane().add(label);
        message.getContentPane().add(continueButton);
        message.getContentPane().add(mainMenu);
        message.getContentPane().add(stop);
        message.setVisible(true);

        if (level == 0) {
            easyBoard[rowSelected][colSelected] = number;
            MainPage.setOldBoard1(easyBoard);
            points = MainPage.player.getEasypoints();
            newPoints = MainPage.player.setEasypointsR(points + increase);
        } else if (level == 1) {
            hardBoard[rowSelected][colSelected] = number;
            MainPage.setOldBoard2(hardBoard);
            points = MainPage.player.getHardpoints();
            newPoints = MainPage.player.setHardpointsR(points + increase);
        }
        if (grid[rowSelected][colSelected] != null) {
            increase = 0;
        } else {
            increase = 5;
        }

        return newPoints;
    }

}
