package sudokugame;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MainPage extends JFrame {

    public JFrame Menu;

    public static Player player;

    public static int oldBoard1[][];
    public static int oldBoard2[][];
    
    public static Help help = new Help();    

    public static int[][] getoldBoard1() {

        if (oldBoard1 == null) {
            oldBoard1 = new int[9][9];
            int board[][] = new int[9][9];
            do {
                board = SudokuGenerator.generate(0);
                Sudoku.point.setText("Total Point is: " + MainPage.player.setEasypointsR(0));
            } while (board[0][0] == -1);
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    oldBoard1[i][j] = board[i][j];
                }
            }
            return oldBoard1;
        } else {
            return oldBoard1;
        }
    }

    public static int[][] getoldBoard2() {
        if (oldBoard2 == null) {
            oldBoard2 = new int[9][9];
            int board[][] = new int[9][9];
            do {
                board = SudokuGenerator.generate(1);
                Sudoku.point.setText("Total Point is: " + MainPage.player.setHardpointsR(0));
            } while (board[0][0] == -1);
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 9; j++) {
                    oldBoard2[i][j] = board[i][j];
                }
            }
            return oldBoard2;
        } else {
            return oldBoard2;
        }
    }

    public static void setOldBoard1(int[][] oldBoard1) {
        MainPage.oldBoard1 = oldBoard1;
    }

    public static void setOldBoard2(int[][] oldBoard2) {
        MainPage.oldBoard2 = oldBoard2;
    }

    public MainPage() {

        //Frame First
        Menu = new JFrame();
        Menu.setTitle("Sudoku Game");
        Menu.setSize(500, 350);
        Menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Panel Add User
        JPanel panel = new JPanel(null);
        panel.setBorder(BorderFactory.createTitledBorder("Menu"));
        panel.setBounds(45, 20, 400, 270);
        Menu.add(panel);

        //Label Username
        JLabel username = new JLabel("Username:");
        username.setBounds(50, 50, 70, 45);
        panel.add(username);

        //TextField name
        JTextField name = new JTextField();
        name.setBounds(140, 60, 220, 25);
        name.setColumns(8);
        panel.add(name);

        //Button Play
        JButton play = new JButton("Play");
        play.setBounds(180, 120, 130, 25);
        panel.add(play);
        play.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                String nameText = name.getText();
                if (!(3 <= nameText.length() && 8 >= nameText.length())) {
                    JOptionPane.showMessageDialog(null, new String[]{"Sorry!! ", "but the Name should between 3 to 8 digits"}, "Alert", JOptionPane.WARNING_MESSAGE);
                } else {
                    player = Player.getPlayer();
                    player.setName(nameText);
                    EventQueue.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                SudokuMaker window = new SudokuMaker();
                                window.newBoard();
                                Menu.setVisible(false);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });

        //Button Help
        JButton help = new JButton("Help");
        help.setBounds(150, 210, 95, 25);
        panel.add(help);
        help.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MainPage.help.helpMessage();
            }
        });

        //Button Exit
        JButton exit = new JButton("Exit");
        exit.setBounds(260, 210, 95, 25);
        panel.add(exit);
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                //Exit Button Code
                JFrame exitfarme = new JFrame("EXIT");
                if (JOptionPane.showConfirmDialog(exitfarme, "Confirm if you want Exit", "EXIT",
                        JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
                    System.exit(0);
                }
            }
        });
        Menu.setVisible(true);
    }
    
    public static void main(String[] args) {
        MainPage Windows = new MainPage();
    }
}
